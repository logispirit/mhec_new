<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {


	public function index()
	{
		$this->load->view('adminDashboard/admin_login_page');
	}


		public function dashboard()
	{
		$this->load->view('adminDashboard/dashboard_main_page');
	}


//////////////////////    project section   /////////////////////////////////////////////

	// show poject 
		public function showProject()
	{
		$this->load->view('adminDashboard/project/show_project');
	}


	// add poject 
		public function addProject()
	{
		$this->load->view('adminDashboard/project/add_new_project');
	}



	// edit poject 
		public function editProject()
	{
		$this->load->view('adminDashboard/project/edit_project');
	}
	
//////////////////////////////////////////////////////////////////////////////////////

//////////////////////    Album section   /////////////////////////////////////////////0
	
	// add photo
		public function addPhoto()
	{
		$this->load->view('adminDashboard/gallery/add_new_images');
	}


}
