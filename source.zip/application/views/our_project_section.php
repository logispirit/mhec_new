<!-- Section 1 start -->
        <div class="col-12">
             <br>
            <span style="font-size: 35px; margin-left: 20px;" class="our_p_title">Our Projects</span>
            <style type="text/css">
              .our_p_title {
                -ms-flex-align: center!important;
                align-items: center!important;
                display: flex;
                justify-content: center;
            }
            </style>
            <br>

            <div class="row">
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="well">
                        <h4>Normal Well</h4>
                        <a href="###"><img src="<?php echo base_url(); ?>source/img/thumbnil (1).jpg" class="img-responsive"></a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="well">
                        <h4>Normal Well</h4>
                        <a href="###"><img src="<?php echo base_url(); ?>source/img/thumbnil (2).jpg" class="img-responsive"></a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6"">
                    <div class="well">
                        <h4>Normal Well</h4>
                        <a href="###"><img src="<?php echo base_url(); ?>source/img/thumbnil (3).jpg" class="img-responsive"></a>
                    </div>
                </div>
                <div class="col-xl-3 col-lg-3 col-md-3 col-sm-6 col-6">
                    <div class="well">
                        <h4>Normal Well</h4>
                        <a href="###"><img src="<?php echo base_url(); ?>source/img/thumbnil (4).jpg" class="img-responsive"></a>
                    </div>
                </div>
            </div>
        </div>
        <!-- End Section 1 -->