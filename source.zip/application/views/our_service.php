<style type="text/css">
.Servis_title {
-ms-flex-align: center!important;
align-items: center!important;
display: flex;
justify-content: center;
}

#servis_div_row h4{
margin: -5px;
color: black;
}

/*#servis_div_row_div{
background-color: rgba(34, 22, 252,0.5);
}*/

#servis_div{
background-color: rgba(0,0,0,0.1);
}

</style>
        


        <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12" id="servis_div">
        <span style="font-size: 35px; margin-left: 20px;" class="Servis_title">Our Servises</span>
        <br>
           
        <div class="row" id="servis_div_row">
            <div class="col-lg-12">
                <div class="col-lg-4">
                    <div class="panel panel-info" >
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"><h4>Feasibility Studies for Highway Projects</h4></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="panel panel-info">
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"><h4>Detail Design of Highways</h4></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="panel panel-info"> 
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"><h4>Traffic Impact Assessment (TIA)</h4></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="col-lg-4">
                    <div class="panel panel-info">
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"><h4>Accident surveys and Analysis</h4></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="panel panel-info">
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"><h4>Environment and Socio-economic Assessment</h4></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="panel panel-info">
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"><h4>Traffic Analysis & Transport Planning</h4></a>
                        </div>
                    </div>
                </div>
            </div>

            <div class="col-lg-12">
                <div class="col-lg-4">
                    <div class="panel panel-info">
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"> <h4>Traffic Signal Design</h4></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="panel panel-info">
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"><h4> Data collection Surveys</h4></a>
                        </div>
                    </div>
                </div>
                <div class="col-lg-4">
                    <div class="panel panel-info">
                        <div class="panel-heading" id="servis_div_row_div">
                            <a href="#" class="text-center"><h4>Accident surveys and Analysis</h4></a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        </div>