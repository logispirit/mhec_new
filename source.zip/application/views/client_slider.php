    <!-- Start client slider -->
    <link href="<?php echo base_url(); ?>source/vendor/client_slider/c_slider_css.css" rel="stylesheet">
    <script src="<?php echo base_url(); ?>source/vendor/client_slider/c_slider_jquery.js" type="text/javascript"></script>
    <script src="<?php echo base_url(); ?>source/vendor/client_slider/c_slider_silk.js"></script>
   <!--  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet"> -->
    <!-- End Client slider -->




    <style type="text/css">
    @media screen and (max-width: 900px) and (min-width: 600px), (min-width: 1100px) {
      #client_slider_div{
        width: 50%;
      }
    }
    </style>





  <div class="col-xl-16 col-lg-6 col-md-6 col-sm-6 col-6" id="client_slider_div">  

    <h2 id="client_slider_h2">Our  Partners</h2>
    <section class="customer-logos slider">
      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/rda.jpg"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/JICA_logo.png"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/Access.png"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/NTC.jpg">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/dimo.jpg">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/nawalokaConstruction.png">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/keangnam.jpg"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/urban_development.jpg">
        </div>
      </a>
    </section>
  </div>









  <div class="col-xl-16 col-lg-6 col-md-6 col-sm-6 col-6" id="client_slider_div">    

    <h2 id="client_slider_h2">Our  Partners</h2>
    <section class="customer-logos slider">
      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/rda.jpg"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/JICA_logo.png"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/Access.png"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/NTC.jpg">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/dimo.jpg">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/nawalokaConstruction.png">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/keangnam.jpg"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/urban_development.jpg">
        </div>
      </a>
    </section>
  </div>







  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6" id="client_slider_div">    

    <h2 id="client_slider_h2">Our  Partners</h2>
    <section class="customer-logos slider">
      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/rda.jpg"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/JICA_logo.png"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/Access.png"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/NTC.jpg">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/dimo.jpg">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/nawalokaConstruction.png">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/keangnam.jpg"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/urban_development.jpg">
        </div>
      </a>
    </section>
  </div>






  <div class="col-xl-6 col-lg-6 col-md-6 col-sm-6 col-6" id="client_slider_div">  
    <h2 id="client_slider_h2">Our  Partners</h2>
    <section class="customer-logos slider">
      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/rda.jpg"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/JICA_logo.png"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/Access.png"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/NTC.jpg">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/dimo.jpg">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/nawalokaConstruction.png">
        </div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/keangnam.jpg"></div>
      </a>

      <a href="#">
        <div class="slide"><img src="<?php echo base_url(); ?>source/img/client_slider/urban_development.jpg">
        </div>
      </a>
    </section>
  </div>



  
<!-- <div class="slide"><img src="../img/client_slider/"></div>
<div class="slide"><img src="../img/client_slider/"></div>
<div class="slide"><img src="../img/client_slider/"></div> -->
</section>
<!-- client_slider -->
<script src="<?php echo base_url(); ?>source/vendor/client_slider/c_slider_js.js"></script>

