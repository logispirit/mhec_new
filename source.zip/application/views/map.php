 <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
    <div class="map-frame">
      <iframe width="100%" height="100%" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="https://www.google.com/maps/embed?pb=!1m14!1m8!1m3!1d15843.851940696737!2d79.9238815!3d6.895031!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x9604b4c1035eae12!2sMaster+Hellie%E2%80%99s+Engineering+Consultants+Pvt.+Ltd!5e0!3m2!1sen!2slk!4v1524130165754">
     </iframe>
    </div>

    
    <style type="text/css">
        .map-frame {
            width: 100%;
            height: 300px;
            position: relative;
        }

        .map-content {
            z-index: 10;
            position: absolute;
            top: 50px;
            left: 50px;
            width: 390px;
            background-color: black;
            color: #FFF;
        }
      </style>
  </div>