<!-- Start WOWSlider.com BODY section -->
        <div id="wowslider-container1">
        <div class="ws_images"><ul>
                 <li><img src="<?php echo base_url(); ?>source/vendor/data1/images/5.jpg" alt=" " title=" " id="wows1_0"/></li>
                <li><img src="<?php echo base_url(); ?>source/vendor/data1/images/6.jpg" alt=" " title=" " id="wows1_0"/></li>
                <li><a href="#"><img src="<?php echo base_url(); ?>source/vendor/data1/images/7.jpg" alt="responsive slider" title=" " id="wows1_1"/></a></li>
                <li><img src="<?php echo base_url(); ?>source/vendor/data1/images/8.jpg" alt=" " title=" " id="wows1_2"/></li>
                <li><img src="<?php echo base_url(); ?>source/vendor/data1/images/9.jpg" alt=" " title=" " id="wows1_2"/></li>
            </ul></div>
           <!--  <div class="ws_bullets">
              <div>
                <a href="#" title=" "><span><img src="<?php echo base_url(); ?>source/vendor/data1/tooltips/5.jpg" alt=" "/>1</span>
                </a>
                <a href="#" title=" "><span><img src="<?php echo base_url(); ?>source/vendor/data1/tooltips/6.jpg" alt=" "/>1</span>
                </a>
                <a href="#" title=" "><span><img src="<?php echo base_url(); ?>source/vendor/data1/tooltips/7.jpg" alt=" "/>2</span>
                </a>
                <a href="#" title="  "><span><img src="<?php echo base_url(); ?>source/vendor/data1/tooltips/8.jpg" alt=" "/>3</span>
                </a>
                <a href="#" title=" "><span><img src="<?php echo base_url(); ?>source/vendor/data1/tooltips/9.jpg" alt=" "/>3</span>
                </a>
               
            </div> -->
          </div>
          <div class="ws_script" style="position:absolute;left:-99%"></div>
        <div class="ws_shadow"></div>
        </div>  
        <script type="text/javascript" src="<?php echo base_url(); ?>source/vendor/engine1/wowslider.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>source/vendor/engine1/script.js"></script>
        <!-- End WOWSlider.com BODY section -->