<html>
<head>  
<link rel="stylesheet" type="text/css" href="<?php echo base_url(); ?>source/vendor/footer/footer_css.css">  
</head>
<body>
<div id="footer_div1">
    <!-- Footer -->
    <div id="footer">
        <div class="container">
            <div class="row text-center text-xs-center text-sm-left text-md-left">
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <h5>Quick links</h5>
                    <ul class="list-unstyled quick-links">
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section1</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section2</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section3</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section4</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section5</a></li>
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <h5>Quick links</h5>
                    <ul class="list-unstyled quick-links">
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section1</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section2</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section3</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section4</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section5</a></li>
                    </ul>
                </div>
                <div class="col-xs-12 col-sm-4 col-md-4">
                    <h5>Quick links</h5>
                    <ul class="list-unstyled quick-links">
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section1</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section2</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section3</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section4</a></li>
                        <li><a href="#"><i class="fa fa-angle-double-right"></i>Section5</a></li>
                    </ul>
                </div>
            </div>
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-5">
                    <ul class="list-unstyled list-inline social text-center">
                        <li class="list-inline-item"><a href="#"><i class="fa fa-facebook faa-pulse animated "></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-twitter faa-pulse animated "></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-instagram faa-pulse animated "></i></a></li>
                        <li class="list-inline-item"><a href="#"><i class="fa fa-google-plus faa-pulse animated "></i></a></li>
                        <li class="list-inline-item"><a href="#" target="_blank"><i class="fa fa-envelope faa-pulse animated "></i></a></li>
                    </ul>
                </div>
                <hr />
            </div>  
            <div class="row">
                <div class="col-xs-12 col-sm-12 col-md-12 mt-2 mt-sm-2 text-center text-white">
                    <p>MHEC IT | 2018 | <a class="text-green ml-2" href="https://www.linkedin.com/in/thevin-malaka-b7458b106" target="_blank">#####</a></p>
                </div>
                <hr />
            </div>  
        </div>
    </div>
    <!-- ./Footer -->
</div>

</body>
</html>


<!-- <p>National Transaction Corporation is a Registered MSP/ISO of Elavon, Inc. Georgia [a wholly owned subsidiary of U.S. Bancorp, Minneapolis, MN]</p>
                    <p class="h6">&copy All right Reversed.<a class="text-green ml-2" href="https://www.sunlimetech.com" target="_blank">Sunlimetech</a></p> -->